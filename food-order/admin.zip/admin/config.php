<?php

    $hostname="http://localhost/food-order";
    $conn=mysqli_connect("localhost","root","","food-order")or die("Connection failed");
?>